`timescale 1ns / 1ps
module ID_EX_reg (
    input  wire        clk, rst_n,
    input  wire        stall,
    input  wire        flush,             // NEW: Flush for control hazards
    input  wire [31:0] pc_in,             // NEW: Actual PC for AUIPC
    input  wire [31:0] pc_plus4_in,
    input  wire [31:0] rs1_data_in,
    input  wire [31:0] rs2_data_in,
    input  wire [31:0] imm_in,
    input  wire [31:0] branch_target_in,
    input  wire [31:0] instr_in,
    input  wire [4:0]  rs1_in,
    input  wire [4:0]  rs2_in,
    input  wire [4:0]  rd_in,
    input  wire [2:0]  funct3_in,
    input  wire [3:0]  AluSel_in,
    input  wire        SrcSel_in,
    input  wire        MemWrite_in,
    input  wire        RegWrite_in,
    input  wire [1:0]  RegWB_in,
    input  wire        AuipcSel_in,
    input  wire        BranchSel_in,
    input  wire        JalrSel_in,
    input  wire        MemRead_in,
    
    output reg  [31:0] pc_out,            // NEW
    output reg  [31:0] pc_plus4_out,
    output reg  [31:0] rs1_data_out,
    output reg  [31:0] rs2_data_out,
    output reg  [31:0] imm_out,
    output reg  [31:0] branch_target_out,
    output reg  [31:0] instr_out,
    output reg  [4:0]  rs1_out,
    output reg  [4:0]  rs2_out,
    output reg  [4:0]  rd_out,
    output reg  [2:0]  funct3_out,
    output reg  [3:0]  AluSel_out,
    output reg         SrcSel_out,
    output reg         MemWrite_out,
    output reg         RegWrite_out,
    output reg  [1:0]  RegWB_out,
    output reg         AuipcSel_out,
    output reg         BranchSel_out,
    output reg         JalrSel_out,
    output reg         MemRead_out
);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n || flush) begin // Flush zeroes out control signals, making it a NOP
            pc_out           <= 32'd0;
            pc_plus4_out     <= 32'd0;
            rs1_data_out     <= 32'd0;
            rs2_data_out     <= 32'd0;
            imm_out          <= 32'd0;
            branch_target_out<= 32'd0;
            instr_out        <= 32'd0;    
            rs1_out          <= 5'd0;
            rs2_out          <= 5'd0;
            rd_out           <= 5'd0;
            funct3_out       <= 3'd0;
            AluSel_out       <= 4'd0;
            SrcSel_out       <= 1'b0;
            MemWrite_out     <= 1'b0;
            RegWrite_out     <= 1'b0;
            RegWB_out        <= 2'b00;
            AuipcSel_out     <= 1'b0;
            BranchSel_out    <= 1'b0;
            JalrSel_out      <= 1'b0;
            MemRead_out      <= 1'b0;
        end else if (stall) begin
            // Bubble: preserve data to avoid issues, but zero control signals
            pc_out           <= pc_in;
            pc_plus4_out     <= pc_plus4_in;
            rs1_data_out     <= rs1_data_in;
            rs2_data_out     <= rs2_data_in;
            imm_out          <= imm_in;
            branch_target_out<= branch_target_in;
            instr_out        <= instr_in;
            rs1_out          <= rs1_in;
            rs2_out          <= rs2_in;
            rd_out           <= rd_in;
            funct3_out       <= funct3_in;
            AluSel_out       <= 4'd0;
            SrcSel_out       <= 1'b0;
            MemWrite_out     <= 1'b0;
            RegWrite_out     <= 1'b0;
            RegWB_out        <= 2'b00;
            AuipcSel_out     <= 1'b0;
            BranchSel_out    <= 1'b0;
            JalrSel_out      <= 1'b0;
            MemRead_out      <= 1'b0;
        end else begin
            pc_out           <= pc_in;
            pc_plus4_out     <= pc_plus4_in;
            rs1_data_out     <= rs1_data_in;
            rs2_data_out     <= rs2_data_in;
            imm_out          <= imm_in;
            branch_target_out<= branch_target_in;
            instr_out        <= instr_in;
            rs1_out          <= rs1_in;
            rs2_out          <= rs2_in;
            rd_out           <= rd_in;
            funct3_out       <= funct3_in;
            AluSel_out       <= AluSel_in;
            SrcSel_out       <= SrcSel_in;
            MemWrite_out     <= MemWrite_in;
            RegWrite_out     <= RegWrite_in;
            RegWB_out        <= RegWB_in;
            AuipcSel_out     <= AuipcSel_in;
            BranchSel_out    <= BranchSel_in;
            JalrSel_out      <= JalrSel_in;
            MemRead_out      <= MemRead_in;
        end
    end

endmodule
