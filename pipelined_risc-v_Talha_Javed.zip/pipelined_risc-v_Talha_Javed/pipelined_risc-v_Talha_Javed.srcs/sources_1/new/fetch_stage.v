`timescale 1ns / 1ps
module fetch_stage (
    input  wire        clk, rst_n,
    input  wire        stall,          // freeze PC
    input  wire [31:0] branch_target,  // from EX (Branch / JAL)
    input  wire [31:0] jalr_target,    // from EX (JALR)
    input  wire        branch_taken,   // from EX (Branch / JAL)
    input  wire        jalr_sel,       // from EX (JALR)
    output wire [31:0] pc,
    output wire [31:0] instr,
    output wire [31:0] pc_plus4
);

    reg [31:0] PC;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)
            PC <= 32'h0;
        else if (stall)
            PC <= PC;               // hold PC on load-use hazard
        else if (jalr_sel)
            PC <= jalr_target;      // JALR resolution
        else if (branch_taken)
            PC <= branch_target;    // Branch or JAL resolution
        else
            PC <= PC + 4;
    end

    assign pc = PC;
    assign pc_plus4 = PC + 4;

    prg_mem u_prg_mem (
        .addr(PC),
        .data(instr)
    );

endmodule
