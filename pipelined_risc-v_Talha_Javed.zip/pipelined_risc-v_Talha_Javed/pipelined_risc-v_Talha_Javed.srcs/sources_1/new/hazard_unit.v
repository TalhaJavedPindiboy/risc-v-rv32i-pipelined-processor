`timescale 1ns / 1ps
module hazard_unit (
    input  wire [4:0] ID_EX_rd,
    input  wire       ID_EX_MemRead,
    input  wire [4:0] IF_ID_rs1,
    input  wire [4:0] IF_ID_rs2,
    output reg        stall,
    output reg        flush
);

    always @(*) begin
        stall = 1'b0;
        flush = 1'b0;
        if (ID_EX_MemRead && (ID_EX_rd != 5'd0) &&
            ((ID_EX_rd == IF_ID_rs1) || (ID_EX_rd == IF_ID_rs2))) begin
            stall = 1'b1;
        end
    end

endmodule
