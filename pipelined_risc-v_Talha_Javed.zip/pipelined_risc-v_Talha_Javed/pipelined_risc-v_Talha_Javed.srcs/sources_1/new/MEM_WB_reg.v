`timescale 1ns / 1ps
module MEM_WB_reg (
    input  wire        clk, rst_n,
    input  wire [31:0] read_data_in,
    input  wire [31:0] alu_result_in,
    input  wire [4:0]  rd_in,
    input  wire [31:0] pc_plus4_in,
    input  wire [31:0] imm_in,
    input  wire        RegWrite_in,
    input  wire [1:0]  RegWB_in,
    output reg  [31:0] read_data_out,
    output reg  [31:0] alu_result_out,
    output reg  [4:0]  rd_out,
    output reg  [31:0] pc_plus4_out,
    output reg  [31:0] imm_out,
    output reg         RegWrite_out,
    output reg  [1:0]  RegWB_out
);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            read_data_out   <= 32'd0;
            alu_result_out  <= 32'd0;
            rd_out          <= 5'd0;
            pc_plus4_out    <= 32'd0;
            imm_out         <= 32'd0;
            RegWrite_out    <= 1'b0;
            RegWB_out       <= 2'b00;
        end else begin
            read_data_out   <= read_data_in;
            alu_result_out  <= alu_result_in;
            rd_out          <= rd_in;
            pc_plus4_out    <= pc_plus4_in;
            imm_out         <= imm_in;
            RegWrite_out    <= RegWrite_in;
            RegWB_out       <= RegWB_in;
        end
    end

endmodule
