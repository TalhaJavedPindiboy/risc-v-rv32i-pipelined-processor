`timescale 1ns / 1ps
module prg_mem(
    input  wire [31:0] addr,
    output wire [31:0] data
);
    reg [31:0] mem [0:1023];
    integer i;
    initial begin
        for (i = 0; i < 1024; i = i + 1) begin
            mem[i] = 32'h00000000;
        end
        mem[0]  = 32'h00a00093; // addi x1, x0, 10
        mem[1]  = 32'hffb00113; // addi x2, x0, -5
        mem[2]  = 32'h002081b3; // add x3, x1, x2
        mem[3]  = 32'h40208233; // sub x4, x1, x2
        mem[4]  = 32'h0040f2b3; // and x5, x1, x4
        mem[5]  = 32'h0020e333; // or x6, x1, x2
        mem[6]  = 32'h0040c3b3; // xor x7, x1, x4
        mem[7]  = 32'h00a21413; // slli x8, x4, 10
        mem[8]  = 32'h01000493; // addi x9, x0, 16
        mem[9]  = 32'h0084a023; // sw x8, 0(x9)
        mem[10] = 32'h0014a223; // sw x1, 4(x9)
        mem[11] = 32'h0004a503; // lw x10, 0(x9)
        mem[12] = 32'h0044a583; // lw x11, 4(x9)
        mem[13] = 32'h00850663; // beq x10, x8, +12
        mem[14] = 32'hfff00613; // addi x12, x0, -1 (should be skipped)
        mem[15] = 32'hfff00613; // addi x12, x0, -1 (should be skipped)
        mem[16] = 32'h00100693; // addi x13, x0, 1
        mem[17] = 32'h00c0076f; // jal x14, +12
        mem[18] = 32'hfff00793; // addi x15, x0, -1 (should be skipped)
        mem[19] = 32'hfff00793; // addi x15, x0, -1 (should be skipped)
        mem[20] = 32'h12345837; // lui x16, 0x12345
        mem[21] = 32'h06000893; // addi x17, x0, 96
        mem[22] = 32'h00488967; // jalr x18, 4(x17)
        mem[23] = 32'hfff00993; // addi x19, x0, -1 (should be skipped)
        mem[24] = 32'hfff00993; // addi x19, x0, -1 (should be skipped)
        mem[25] = 32'h0000006f; // jal x0, 0 (infinite loop)
    end
    assign data = mem[addr[31:2]];
endmodule
