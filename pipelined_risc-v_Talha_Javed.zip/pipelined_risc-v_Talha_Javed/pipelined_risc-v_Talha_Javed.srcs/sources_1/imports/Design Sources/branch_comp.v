`timescale 1ns / 1ps
module branch_comp (
    input  wire [31:0] data1, data2,
    input  wire [2:0]  br_type, // funct3
    output reg         br_taken
);

    always @(*) begin
        case (br_type)
            3'b000: br_taken = (data1 == data2);                      // BEQ
            3'b001: br_taken = (data1 != data2);                      // BNE
            3'b100: br_taken = ($signed(data1) < $signed(data2));     // BLT
            3'b101: br_taken = ($signed(data1) >= $signed(data2));    // BGE
            3'b110: br_taken = (data1 < data2);                       // BLTU
            3'b111: br_taken = (data1 >= data2);                      // BGEU
            default: br_taken = 1'b0;
        endcase
    end

endmodule