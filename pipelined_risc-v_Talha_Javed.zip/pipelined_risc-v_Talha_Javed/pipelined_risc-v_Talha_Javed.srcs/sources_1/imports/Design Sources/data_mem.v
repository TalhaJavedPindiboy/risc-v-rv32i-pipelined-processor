`timescale 1ns / 1ps
module data_mem(
    input clk,rst_n,
    input wr_en,
    input [31:0] data_in,
    input [31:0] addr,
    output [31:0] data_out
    );
    reg [31:0] mem [0:1023];
    integer i;
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            for(i = 0; i < 1024; i=i+1)begin
                mem[i] <= 32'h00000000;
            end
        end
        
        else if(wr_en)begin
            //write to address, >>2 because i am using 32bit wide mem
            mem[addr[31:2]] <= data_in;
        end
    end
    //Asynchronous Read
    assign data_out = mem[addr[31:2]];
    
endmodule
