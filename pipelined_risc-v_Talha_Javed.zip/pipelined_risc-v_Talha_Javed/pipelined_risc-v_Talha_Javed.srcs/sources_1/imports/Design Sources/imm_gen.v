`timescale 1ns / 1ps
module imm_gen(
    input  wire [31:0] instruction,
    output reg  [31:0] imm
);
    
    wire [6:0] opcode;
    assign opcode = instruction[6:0];

    always @(*) begin
        case (opcode)
            // I-type (ALU immediate, Loads, JALR)
            // Opcode: 0010011 (OP-IMM), 0000011 (LOAD), 1100111 (JALR)
            7'b0010011, 7'b0000011, 7'b1100111: begin
                imm = {{20{instruction[31]}}, instruction[31:20]};
            end
            
            // S-type (Stores)
            // Opcode: 0100011 (STORE)
            7'b0100011: begin
                imm = {{20{instruction[31]}}, instruction[31:25], instruction[11:7]};
            end
            
            // B-type (Branches)
            // Opcode: 1100011 (BRANCH)
            // Note: The LSB is implicitly 0 because instructions are half-word aligned
            7'b1100011: begin
                imm = {{20{instruction[31]}}, instruction[7], instruction[30:25], instruction[11:8], 1'b0};
            end
            
            // U-type (LUI, AUIPC)
            // Opcode: 0110111 (LUI), 0010111 (AUIPC)
            // Note: The lower 12 bits are filled with 0s
            7'b0110111, 7'b0010111: begin
                imm = {instruction[31:12], 12'b0};
            end
            
            // J-type (JAL)
            // Opcode: 1101111 (JAL)
            // Note: The LSB is implicitly 0
            7'b1101111: begin
                imm = {{12{instruction[31]}}, instruction[19:12], instruction[20], instruction[30:21], 1'b0};
            end
            
            // Default case to prevent latches
            default: begin
                imm = 32'd0;
            end
        endcase
    end

endmodule
