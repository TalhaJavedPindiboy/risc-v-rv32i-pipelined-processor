`timescale 1ns / 1ps
module alu_decoder(
    input  wire [6:0] opcode,
    input  wire [2:0] funct3,
    input  wire       funct7_5, // Instruction bit 30
    output reg  [3:0] AluSel
);

    always @(*) begin
        AluSel = 4'b0000; 

        case (opcode)
            7'b0000011, 7'b0100011: begin
                AluSel = 4'b0000; // ADD
            end
            7'b1100011: begin
                AluSel = 4'b0001; // SUB
            end
            7'b0110011: begin
                case (funct3)
                    3'b000: AluSel = funct7_5 ? 4'b0001 : 4'b0000; // SUB if bit30 is 1, else ADD
                    3'b001: AluSel = 4'b0010;                      // SLL
                    3'b010: AluSel = 4'b0011;                      // SLT
                    3'b011: AluSel = 4'b0100;                      // SLTU
                    3'b100: AluSel = 4'b0101;                      // XOR
                    3'b101: AluSel = funct7_5 ? 4'b0111 : 4'b0110; // SRA if bit30 is 1, else SRL
                    3'b110: AluSel = 4'b1000;                      // OR
                    3'b111: AluSel = 4'b1001;                      // AND
                endcase
            end
            7'b0010011: begin
                case (funct3)
                    3'b000: AluSel = 4'b0000;                      // ADD (ADDI)
                    3'b001: AluSel = 4'b0010;                      // SLL (SLLI)
                    3'b010: AluSel = 4'b0011;                      // SLT (SLTI)
                    3'b011: AluSel = 4'b0100;                      // SLTU (SLTIU)
                    3'b100: AluSel = 4'b0101;                      // XOR (XORI)
                    3'b101: AluSel = funct7_5 ? 4'b0111 : 4'b0110; // SRAI if bit30 is 1, else SRLI
                    3'b110: AluSel = 4'b1000;                      // OR (ORI)
                    3'b111: AluSel = 4'b1001;                      // AND (ANDI)
                endcase
            end
            7'b0010111, 7'b1100111: begin
                AluSel = 4'b0000; // ADD
            end
        endcase
    end
endmodule
