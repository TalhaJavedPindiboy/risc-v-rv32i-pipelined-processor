`timescale 1ns / 1ps
module reg_file(
    input clk, rst_n,
    input wr_en,
    input [4:0] addr1, addr2, wr_addr,
    input [31:0] data_in,
    output [31:0] data1, data2
    );
    reg [31:0]mem [0:31];
    integer i;
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            for(i = 0; i < 32; i=i+1)begin
                mem[i] <= 32'h00000000;
            end
        end
        
        else if (wr_en && (wr_addr != 5'd0))begin
                mem[wr_addr] <= data_in;
        end
    end
    assign data1 = (addr1 == 5'd0)? 32'h00000000 : mem[addr1];
    assign data2 = (addr2 == 5'd0)? 32'h00000000 : mem[addr2];
endmodule
