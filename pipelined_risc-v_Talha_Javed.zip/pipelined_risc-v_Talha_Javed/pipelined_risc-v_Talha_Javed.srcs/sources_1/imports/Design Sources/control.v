`timescale 1ns / 1ps
module controller(
    input  wire [6:0] opcode,
    input  wire       br_taken,          // not used in pipelined version
    output reg        SrcSel,
    output reg        MemWrite,
    output reg        RegWrite,
    output reg  [1:0] RegWB,
    output reg        AuipcSel,
    output reg        BranchSel,
    output reg        JalrSel,
    output reg        MemRead            // NEW
);

    always @(*) begin
        // Defaults
        SrcSel    = 1'b0;
        MemWrite  = 1'b0;
        RegWrite  = 1'b0;
        RegWB     = 2'b00;
        AuipcSel  = 1'b0;
        BranchSel = 1'b0;
        JalrSel   = 1'b0;
        MemRead   = 1'b0;

        case (opcode)
            7'b0110011: begin  // R-type
                SrcSel    = 1'b0;
                MemWrite  = 1'b0;
                RegWrite  = 1'b1;
                RegWB     = 2'b00;
                AuipcSel  = 1'b0;
                BranchSel = 1'b0;
                JalrSel   = 1'b0;
                MemRead   = 1'b0;
            end
            7'b0010011: begin  // I-type ALU
                SrcSel    = 1'b1;
                MemWrite  = 1'b0;
                RegWrite  = 1'b1;
                RegWB     = 2'b00;
                AuipcSel  = 1'b0;
                BranchSel = 1'b0;
                JalrSel   = 1'b0;
                MemRead   = 1'b0;
            end
            7'b0000011: begin  // Load
                SrcSel    = 1'b1;
                MemWrite  = 1'b0;
                RegWrite  = 1'b1;
                RegWB     = 2'b01;
                AuipcSel  = 1'b0;
                BranchSel = 1'b0;
                JalrSel   = 1'b0;
                MemRead   = 1'b1;      // set for hazard detection
            end
            7'b0100011: begin  // Store
                SrcSel    = 1'b1;
                MemWrite  = 1'b1;
                RegWrite  = 1'b0;
                RegWB     = 2'b00;
                AuipcSel  = 1'b0;
                BranchSel = 1'b0;
                JalrSel   = 1'b0;
                MemRead   = 1'b0;
            end
            7'b1100011: begin  // Branch
                SrcSel    = 1'b0;
                MemWrite  = 1'b0;
                RegWrite  = 1'b0;
                RegWB     = 2'b00;
                AuipcSel  = 1'b0;
                BranchSel = 1'b1;      // unconditional - taken decision in EX
                JalrSel   = 1'b0;
                MemRead   = 1'b0;
            end
            7'b1101111: begin  // JAL
                SrcSel    = 1'b0;
                MemWrite  = 1'b0;
                RegWrite  = 1'b1;
                RegWB     = 2'b10;     // PC+4
                AuipcSel  = 1'b0;
                BranchSel = 1'b1;      // unconditional
                JalrSel   = 1'b0;
                MemRead   = 1'b0;
            end
            7'b1100111: begin  // JALR
                SrcSel    = 1'b1;
                MemWrite  = 1'b0;
                RegWrite  = 1'b1;
                RegWB     = 2'b10;     // PC+4
                AuipcSel  = 1'b0;
                BranchSel = 1'b0;
                JalrSel   = 1'b1;
                MemRead   = 1'b0;
            end
            7'b0010111: begin  // AUIPC
                SrcSel    = 1'b1;
                MemWrite  = 1'b0;
                RegWrite  = 1'b1;
                RegWB     = 2'b00;
                AuipcSel  = 1'b1;
                BranchSel = 1'b0;
                JalrSel   = 1'b0;
                MemRead   = 1'b0;
            end
            7'b0110111: begin  
                SrcSel    = 1'b0;
                MemWrite  = 1'b0;
                RegWrite  = 1'b1;
                RegWB     = 2'b11;     
                AuipcSel  = 1'b0;
                BranchSel = 1'b0;
                JalrSel   = 1'b0;
                MemRead   = 1'b0;
            end
            default: ;
        endcase
    end
endmodule
