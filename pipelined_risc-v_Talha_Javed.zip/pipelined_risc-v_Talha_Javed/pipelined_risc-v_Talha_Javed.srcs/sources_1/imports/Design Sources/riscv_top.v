`timescale 1ns / 1ps
module riscv_top (
    input  wire        clk,
    input  wire        rst_n,
    output wire [31:0] probe_pc,
    output wire [31:0] probe_alu_out,
    output wire [31:0] probe_wb_data
);    
    wire [31:0] pc_IF, pc_plus4_IF, instr_IF;
    wire [31:0] pc_ID, pc_plus4_ID, instr_ID;

    
    wire [31:0] pc_ID_EX, pc_plus4_ID_EX, rs1_data_ID_EX, rs2_data_ID_EX, imm_ID_EX,
                branch_target_ID_EX, instr_ID_EX;
    wire [4:0]  rs1_ID_EX, rs2_ID_EX, rd_ID_EX;
    wire [2:0]  funct3_ID_EX;
    wire [3:0]  AluSel_ID_EX;
    wire        SrcSel_ID_EX, MemWrite_ID_EX, RegWrite_ID_EX, AuipcSel_ID_EX,
                BranchSel_ID_EX, JalrSel_ID_EX, MemRead_ID_EX;
    wire [1:0]  RegWB_ID_EX;    
    wire [31:0] alu_result_EX_MEM, rs2_data_EX_MEM, pc_plus4_EX_MEM, imm_EX_MEM;
    wire [4:0]  rd_EX_MEM;
    wire        RegWrite_EX_MEM, MemWrite_EX_MEM, MemRead_EX_MEM,
                BranchSel_EX_MEM, branch_taken_EX_MEM;
    wire [1:0]  RegWB_EX_MEM;    
    wire [31:0] read_data_MEM_WB, alu_result_MEM_WB, pc_plus4_MEM_WB, imm_MEM_WB;
    wire [4:0]  rd_MEM_WB;
    wire        RegWrite_MEM_WB;
    wire [1:0]  RegWB_MEM_WB;    
    wire        SrcSel_ID, MemWrite_ID, RegWrite_ID, AuipcSel_ID,
                BranchSel_ID, JalrSel_ID, MemRead_ID;
    wire [1:0]  RegWB_ID;
    wire [3:0]  AluSel_ID;
    wire [2:0]  funct3_ID;
    wire [31:0] rs1_data, rs2_data, imm;
    wire [4:0]  rs1, rs2, rd;
    wire [31:0] alu_in1, alu_in2, alu_out, store_data_comb;
    wire [31:0] read_data;       
    wire [31:0] wb_data;
    wire        br_taken;
    wire [1:0]  ForwardA, ForwardB;
    wire        stall, flush_pipeline;

    fetch_stage fetch (
        .clk(clk),
        .rst_n(rst_n),
        .stall(stall),
        .branch_target(branch_target_ID_EX),
        .jalr_target(alu_out),              
        .branch_taken(branch_taken_comb),   
        .jalr_sel(JalrSel_ID_EX),           
        .pc(pc_IF),
        .instr(instr_IF),
        .pc_plus4(pc_plus4_IF)
    );
    IF_ID_reg if_id (
        .clk(clk),
        .rst_n(rst_n),
        .stall(stall),
        .flush(flush_pipeline),
        .pc_in(pc_IF),         
        .pc_plus4_in(pc_plus4_IF),
        .instr_in(instr_IF),
        .pc_out(pc_ID),
        .pc_plus4_out(pc_plus4_ID),
        .instr_out(instr_ID)
    );
    assign rs1 = instr_ID[19:15];
    assign rs2 = instr_ID[24:20];
    assign rd  = instr_ID[11:7];
    assign funct3_ID = instr_ID[14:12];

    reg_file u_reg_file (
        .clk(clk),
        .rst_n(rst_n),
        .wr_en(RegWrite_MEM_WB),
        .addr1(rs1),
        .addr2(rs2),
        .wr_addr(rd_MEM_WB),
        .data_in(wb_data),
        .data1(rs1_data),
        .data2(rs2_data)
    );

    imm_gen u_imm_gen (
        .instruction(instr_ID),
        .imm(imm)
    );

    controller u_controller (
        .opcode(instr_ID[6:0]),
        .br_taken(1'b0),
        .SrcSel(SrcSel_ID),
        .MemWrite(MemWrite_ID),
        .RegWrite(RegWrite_ID),
        .RegWB(RegWB_ID),
        .AuipcSel(AuipcSel_ID),
        .BranchSel(BranchSel_ID),
        .JalrSel(JalrSel_ID),
        .MemRead(MemRead_ID)
    );

    alu_decoder u_alu_decoder (
        .opcode(instr_ID[6:0]),
        .funct3(funct3_ID),
        .funct7_5(instr_ID[30]),
        .AluSel(AluSel_ID)
    );
    wire [31:0] branch_target = pc_ID + imm;
    ID_EX_reg id_ex (
        .clk(clk),
        .rst_n(rst_n),
        .stall(stall),
        .flush(flush_pipeline),
        .pc_in(pc_ID),         
        .pc_plus4_in(pc_plus4_ID),
        .rs1_data_in(rs1_data),
        .rs2_data_in(rs2_data),
        .imm_in(imm),
        .branch_target_in(branch_target),
        .instr_in(instr_ID),
        .rs1_in(rs1),
        .rs2_in(rs2),
        .rd_in(rd),
        .funct3_in(funct3_ID),
        .AluSel_in(AluSel_ID),
        .SrcSel_in(SrcSel_ID),
        .MemWrite_in(MemWrite_ID),
        .RegWrite_in(RegWrite_ID),
        .RegWB_in(RegWB_ID),
        .AuipcSel_in(AuipcSel_ID),
        .BranchSel_in(BranchSel_ID),
        .JalrSel_in(JalrSel_ID),
        .MemRead_in(MemRead_ID),
        // outputs
        .pc_out(pc_ID_EX),
        .pc_plus4_out(pc_plus4_ID_EX),
        .rs1_data_out(rs1_data_ID_EX),
        .rs2_data_out(rs2_data_ID_EX),
        .imm_out(imm_ID_EX),
        .branch_target_out(branch_target_ID_EX),
        .instr_out(instr_ID_EX),
        .rs1_out(rs1_ID_EX),
        .rs2_out(rs2_ID_EX),
        .rd_out(rd_ID_EX),
        .funct3_out(funct3_ID_EX),
        .AluSel_out(AluSel_ID_EX),
        .SrcSel_out(SrcSel_ID_EX),
        .MemWrite_out(MemWrite_ID_EX),
        .RegWrite_out(RegWrite_ID_EX),
        .RegWB_out(RegWB_ID_EX),
        .AuipcSel_out(AuipcSel_ID_EX),
        .BranchSel_out(BranchSel_ID_EX),
        .JalrSel_out(JalrSel_ID_EX),
        .MemRead_out(MemRead_ID_EX)
    );
    forwarding_unit fwd (
        .ID_EX_rs1(rs1_ID_EX),
        .ID_EX_rs2(rs2_ID_EX),
        .EX_MEM_rd(rd_EX_MEM),
        .MEM_WB_rd(rd_MEM_WB),
        .EX_MEM_RegWrite(RegWrite_EX_MEM),
        .MEM_WB_RegWrite(RegWrite_MEM_WB),
        .ForwardA(ForwardA),
        .ForwardB(ForwardB)
    );
    wire [31:0] forwarded_rs1 = (ForwardA == 2'b10) ? alu_result_EX_MEM :
                                (ForwardA == 2'b01) ? wb_data :
                                rs1_data_ID_EX;

    
    assign alu_in1 = (AuipcSel_ID_EX) ? pc_ID_EX : forwarded_rs1;

    assign alu_in2 = (SrcSel_ID_EX) ? imm_ID_EX :
                     (ForwardB == 2'b10) ? alu_result_EX_MEM :
                     (ForwardB == 2'b01) ? wb_data :
                     rs2_data_ID_EX;

    assign store_data_comb = (ForwardB == 2'b10) ? alu_result_EX_MEM :
                             (ForwardB == 2'b01) ? wb_data :
                             rs2_data_ID_EX;

    alu u_alu (
        .AluSel(AluSel_ID_EX),
        .data1(alu_in1),
        .data2(alu_in2),
        .data_out(alu_out)
    );

    branch_comp u_branch_comp (
        .data1(forwarded_rs1),
        .data2(alu_in2),
        .br_type(funct3_ID_EX),
        .br_taken(br_taken)
    );
    wire branch_taken_comb = BranchSel_ID_EX && (br_taken || (instr_ID_EX[6:0] == 7'b1101111));
    assign flush_pipeline = branch_taken_comb || JalrSel_ID_EX;
    EX_MEM_reg ex_mem (
        .clk(clk),
        .rst_n(rst_n),
        .alu_result_in(alu_out),
        .rs2_data_in(store_data_comb),
        .rd_in(rd_ID_EX),
        .pc_plus4_in(pc_plus4_ID_EX),
        .imm_in(imm_ID_EX),
        .RegWrite_in(RegWrite_ID_EX),
        .MemWrite_in(MemWrite_ID_EX),
        .MemRead_in(MemRead_ID_EX),
        .RegWB_in(RegWB_ID_EX),
        .BranchSel_in(BranchSel_ID_EX),
        .branch_taken_in(branch_taken_comb),
        .alu_result_out(alu_result_EX_MEM),
        .rs2_data_out(rs2_data_EX_MEM),
        .rd_out(rd_EX_MEM),
        .pc_plus4_out(pc_plus4_EX_MEM),
        .imm_out(imm_EX_MEM),
        .RegWrite_out(RegWrite_EX_MEM),
        .MemWrite_out(MemWrite_EX_MEM),
        .MemRead_out(MemRead_EX_MEM),
        .RegWB_out(RegWB_EX_MEM),
        .BranchSel_out(BranchSel_EX_MEM),
        .branch_taken_out(branch_taken_EX_MEM)
    );
    data_mem u_data_mem (
        .clk(clk),
        .rst_n(rst_n),
        .wr_en(MemWrite_EX_MEM),
        .data_in(rs2_data_EX_MEM),
        .addr(alu_result_EX_MEM),
        .data_out(read_data)
    );
    MEM_WB_reg mem_wb (
        .clk(clk),
        .rst_n(rst_n),
        .read_data_in(read_data),
        .alu_result_in(alu_result_EX_MEM),
        .rd_in(rd_EX_MEM),
        .pc_plus4_in(pc_plus4_EX_MEM),
        .imm_in(imm_EX_MEM),
        .RegWrite_in(RegWrite_EX_MEM),
        .RegWB_in(RegWB_EX_MEM),
        .read_data_out(read_data_MEM_WB),
        .alu_result_out(alu_result_MEM_WB),
        .rd_out(rd_MEM_WB),
        .pc_plus4_out(pc_plus4_MEM_WB),
        .imm_out(imm_MEM_WB),
        .RegWrite_out(RegWrite_MEM_WB),
        .RegWB_out(RegWB_MEM_WB)
    );
    assign wb_data = (RegWB_MEM_WB == 2'b01) ? read_data_MEM_WB :
                     (RegWB_MEM_WB == 2'b10) ? pc_plus4_MEM_WB :
                     (RegWB_MEM_WB == 2'b11) ? imm_MEM_WB :
                     alu_result_MEM_WB;
    hazard_unit hazard (
        .ID_EX_rd(rd_ID_EX),
        .ID_EX_MemRead(MemRead_ID_EX),
        .IF_ID_rs1(rs1),
        .IF_ID_rs2(rs2),
        .stall(stall),
        .flush()
    );

    assign probe_pc = pc_IF;
    assign probe_alu_out = alu_out;
    assign probe_wb_data = wb_data;
endmodule
