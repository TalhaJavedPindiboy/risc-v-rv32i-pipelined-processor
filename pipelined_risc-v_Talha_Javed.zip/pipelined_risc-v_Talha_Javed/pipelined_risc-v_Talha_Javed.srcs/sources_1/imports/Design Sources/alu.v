`timescale 1ns / 1ps
module alu(
    input  wire [3:0]  AluSel,
    input  wire [31:0] data1, data2,
    output reg  [31:0] data_out
);
    always @(*) begin
        case (AluSel)
            4'b0000: data_out = data1 + data2;                                    // ADD
            4'b0001: data_out = data1 - data2;                                    // SUB
            4'b0010: data_out = data1 << data2[4:0];                              // SLL
            4'b0011: data_out = ($signed(data1) < $signed(data2)) ? 32'd1 : 32'd0; // SLT
            4'b0100: data_out = (data1 < data2) ? 32'd1 : 32'd0;                  // SLTU
            4'b0101: data_out = data1 ^ data2;                                    // XOR
            4'b0110: data_out = data1 >> data2[4:0];                              // SRL
            4'b0111: data_out = $signed(data1) >>> data2[4:0];                    // SRA
            4'b1000: data_out = data1 | data2;                                    // OR
            4'b1001: data_out = data1 & data2;                                    // AND
            default: data_out = 32'd0;
        endcase
    end
    
endmodule




