`timescale 1ns / 1ps
module tb_riscv_top();

    reg clk, rst_n;
    wire [31:0] probe_pc;
    wire [31:0] probe_alu_out;
    wire [31:0] probe_wb_data;

    riscv_top uut (
        .clk(clk),
        .rst_n(rst_n),
        .probe_pc(probe_pc),
        .probe_alu_out(probe_alu_out),
        .probe_wb_data(probe_wb_data)
    );

    initial begin
        clk = 0;
        forever #5 clk = ~clk; 
    end

    initial begin
        $display("==================================================");
        $display("Starting RISC-V Pipeline Simulation");
        
        // Assert Reset
        rst_n = 0;
        #25; 
        
        // De-assert Reset
        rst_n = 1;

        // Wait for the program to reach the final instruction.
        // In prg_mem.v, mem[25] is address 0x64 (jal x0, 0)
        wait(probe_pc == 32'h00000064);
        
        // Allow a few extra clock cycles for the final instruction to 
        // propagate through the ID, EX, MEM, and WB stages.
        #50; 
        
        $display("Simulation Complete: Reached expected end of program (PC=0x64).");
        $display("==================================================");
        $finish;
    end

    // Watchdog Timer (Safety Catch)
    // If a branch logic bug causes the PC to jump to an invalid space 
    // and miss 0x64, this prevents Vivado from simulating infinitely.
    initial begin
        #2000; 

        $display("ERROR: Simulation Timeout Reached! Check branch logic.");
        $display("==================================================");
        $finish;
    end

    // Pipeline Probe Monitor
    // Using $strobe ensures we sample the signals at the very end of the time step,
    // avoiding race conditions with combinational logic updates.
    always @(posedge clk) begin
        if (rst_n) begin
            $strobe("Time=%7t ns | PC=%h | ALU_Out=%h | WB_Data=%h", 
                     $time, probe_pc, probe_alu_out, probe_wb_data);
        end
    end

endmodule